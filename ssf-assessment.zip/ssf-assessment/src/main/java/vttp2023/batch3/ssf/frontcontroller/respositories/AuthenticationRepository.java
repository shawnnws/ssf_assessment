package vttp2023.batch3.ssf.frontcontroller.respositories;

public class AuthenticationRepository {

	// TODO Task 5
	// Use this class to implement CRUD operations on Redis

}
