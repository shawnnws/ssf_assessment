package vttp2023.batch3.ssf.frontcontroller.controllers;

public class FrontController {

	// TODO: Task 2, Task 3, Task 4, Task 6
	
}
