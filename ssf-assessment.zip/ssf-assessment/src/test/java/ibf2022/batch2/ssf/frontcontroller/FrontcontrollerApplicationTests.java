package ibf2022.batch2.ssf.frontcontroller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontcontrollerApplicationTests {

	@Test
	void contextLoads() {
	}

}
